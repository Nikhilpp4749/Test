
print("hello me")
print('o----')
print(' ||||')
print('*' * 10)