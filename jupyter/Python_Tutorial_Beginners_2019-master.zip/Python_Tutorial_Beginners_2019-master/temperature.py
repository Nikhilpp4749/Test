temperature = 30

if temperature > 30:
    print("it's a hot day")
elif temperature < 10:
    print("It's a cold day")
else:
    print("it's neither hot nor cold")