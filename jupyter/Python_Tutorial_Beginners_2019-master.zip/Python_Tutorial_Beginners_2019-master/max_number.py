numbers = [10, 2, 3, 455, 5, 6]

max = numbers[0]
for number in numbers:
    if number > max:
        max = number

print(max)


    