x_lengths = [5, 2, 5, 2, 2]

for length in x_lengths:
    print('x'*length)
    