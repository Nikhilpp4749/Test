

course = "Python's Course for Beginners"
print(course)
course = 'Python Course for "Beginners"'
print(course)
course = '''
Hi John,

Here is our first email to you.

Thank you,
The support team

'''
print(course)
course = 'Python for Beginners'
print(course)
print('course: ' + course[:6])

another = course[:]
print('another course:', another)