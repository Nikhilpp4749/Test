


course = 'Python for Beginners'

print(len(course))

print(course.upper())

print(course.lower())
print(course)

print(course.find('Beginners'))
print(course.replace('Beginners', 'Absolute Beginners'))

print('Python' in course)
print('python' in course)