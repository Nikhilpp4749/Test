

name = input('What is your name? ')
color = input('What is your favorite color? ')

print(f"{name} likes {color}")