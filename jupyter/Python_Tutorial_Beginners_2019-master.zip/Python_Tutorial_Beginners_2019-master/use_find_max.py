import utils

list_max = utils.find_max([200, 17, 1, 11, 300, 400, 1])
print(list_max)

try_alpha = utils.find_max(['C', 'T', 'a', 'r', 't', 'R'])
try_alpha2 = utils.find_max(['C', 'T', 'R'])
try_alpha3 = utils.find_max(["Zebra", "Cat", "Dog", "Elephant", "Anteater"])
print(try_alpha3)