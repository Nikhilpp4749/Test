import converters
from converters import lbs_to_kg

print(converters.kg_to_lbs(70))
print(lbs_to_kg(44))
