#import ecommerce.shipping
#ecommerce.shipping.calc_shipping()
from ecommerce import shipping
shipping.calc_shipping()
