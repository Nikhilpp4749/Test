

birth_year = input('Birth year? ')
print(type(birth_year))
age = 2019 - int(birth_year)
print(type(age))
print(f"Age: {age} ")