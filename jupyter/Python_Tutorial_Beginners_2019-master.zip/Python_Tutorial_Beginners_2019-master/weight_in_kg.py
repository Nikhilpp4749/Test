

pounds = input('Weight in pounts? ')
kg = int(pounds) / 2.204

print(f"Weight in Kg: {kg} ")